package test.four;

public class SubtractOperation extends AbstractOperation {
    @Override
    public double operate(int firstNumber, int secondNumber) {
        return firstNumber-secondNumber;
    }
}
